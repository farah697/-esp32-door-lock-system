#include <Arduino_GFX_Library.h>
#include <Keypad.h>
#include <ESP32Servo.h>
#include <Preferences.h> 

#define TFT_RST   4   
#define TFT_DC    2   
#define TFT_SCL  18   
#define TFT_SDA  23   

Arduino_DataBus *bus = new Arduino_ESP32SPI(TFT_DC, -1, TFT_SCL, TFT_SDA);
Arduino_GFX *tft = new Arduino_ST7789(bus, TFT_RST, 0, true);


const int buzzerPin = 33;
const int servoPin = 15; 
Servo myServo;


const byte ROWS = 4; 
const byte COLS = 3; 

char keys[ROWS][COLS] = {
  {'9', '6', '3'}, 
  {'8', '5', '2'}, 
  {'7', '4', '1'}, 
  {'*', '0', '#'}  
};

byte rowPins[ROWS] = {13, 12, 14, 27}; 
byte colPins[COLS] = {26, 25, 32}; 

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

Preferences preferences;
String password = "1234"; 
String input = "";

void drawPasswordScreen() { 
  tft->fillScreen(0x0000); 
  tft->setCursor(20, 50);
  tft->setTextColor(0xFFFF); 
  tft->setTextSize(2);
  tft->print("SIFRE GIRINIZ:");

  String stars = "";
  for(int i = 0; i < input.length(); i++) { stars += "*"; }
  tft->setCursor(20, 100);
  tft->setTextColor(0xF800);
  tft->setTextSize(3); 
  tft->print(stars);
}

void setup() {
  pinMode(buzzerPin, OUTPUT);
  myServo.attach(servoPin);
  myServo.write(0); 
  
  tft->begin();

  
  preferences.begin("lock-system", false);
  password = preferences.getString("pwd", "1234"); 
  
  drawPasswordScreen(); 
}

void beepError() { 
  tone(buzzerPin, 3000, 150); delay(200); tone(buzzerPin, 3000, 150);
}

void beepSuccess() {
  tone(buzzerPin, 4000, 400);
}

 
void changePasswordProcedure() {
  tft->fillScreen(0x0000);
  tft->setCursor(20, 40);
  tft->setTextColor(0xFDA0);  
  tft->setTextSize(2);
  tft->print("CHANGE CODE?");
  tft->setCursor(20, 90);
  tft->setTextColor(0xFFFF);
  tft->setTextSize(2);
  tft->print("Press [5] to YES");
  tft->setCursor(20, 130);
  tft->print("Any key to NO");

  
  char choice = 0;
  while(choice == 0) {
    choice = keypad.getKey();
  }

  
  if (choice == '5') {
    tone(buzzerPin, 2000, 50);
    String newPwd = "";
    
    tft->fillScreen(0x0000);
    tft->setCursor(20, 50);
    tft->setTextColor(0xFDA0); 
    tft->print("NEW PASSWORD:");

   
    while(newPwd.length() < 4) {
      char digit = keypad.getKey();
      
      if(digit && digit != '*' && digit != '#') {
        tone(buzzerPin, 2000, 50);
        newPwd += digit;
        
        
        tft->setCursor(20 + (newPwd.length() * 25), 110);
        tft->setTextColor(0xFDA0);
        tft->setTextSize(3);
        tft->print("*");
      }
    }

    
    password = newPwd;
    preferences.putString("pwd", password); 
    
    tft->fillScreen(0x0000);
    tft->setCursor(20, 80);
    tft->setTextColor(0x07E0); 
    tft->setTextSize(2);
    tft->print("CODE CHANGED!");
    beepSuccess();
    delay(2000);
  } else {
    
    tone(buzzerPin, 2000, 50);
  }
}

void loop() {
  char key = keypad.getKey();

  if (key) {
    tone(buzzerPin, 2000, 50); 

    if (key == '*' || key == '#') {
      input = "";
      drawPasswordScreen();
    } 
    else {
      if (input.length() < 4) {
        input += key;
        drawPasswordScreen(); 

       
        if (input.length() == 4) {
          delay(400); 
          
          if (input == password) {
            tft->fillScreen(0x0000);
            tft->setCursor(20, 80);
            tft->setTextColor(0x07E0); 
            tft->setTextSize(2);
            tft->print("HOS GELDINIZ"); 
            
            beepSuccess();
            myServo.write(90); 
            delay(3000);       
            myServo.write(0);  
            
                 
            changePasswordProcedure();
          } 
          else {
            tft->fillScreen(0x0000);
            tft->setCursor(20, 80);
            tft->setTextColor(0xF800);  
            tft->setTextSize(2);
            tft->print("YANLIS SIFRE"); 
            beepError();
            delay(2000); 
          }
          input = ""; 
          drawPasswordScreen();
        }
      }
    }
  }
}